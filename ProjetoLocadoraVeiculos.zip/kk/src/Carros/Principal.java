package Carros;

public class Principal {
    public static void main(String[] args) {
        MenuLocadoraVeiculos menu = new MenuLocadoraVeiculos();
        menu.executarLocadoraVeiculos();
    }
}