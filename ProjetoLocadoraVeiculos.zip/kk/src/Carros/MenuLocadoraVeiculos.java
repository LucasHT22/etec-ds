package Carros;
import javax.swing.JOptionPane;




public class MenuLocadoraVeiculos {
    AlugarVeiculo alugarVeiculo = new AlugarVeiculo();
    CustoAluguelVeiculo custos = new CustoAluguelVeiculo();
    ConversorNumeros conversor = new ConversorNumeros();
    EntradaSaidaDados io = new EntradaSaidaDados();
    CadastrarVeiculo veiculo = new CadastrarVeiculo();
    int opcao;

    public void executarLocadoraVeiculos() {
        do {
            String menu = """
                Menu
                1 - Cadastrar Aluguel
                2 - Cadastrar Veículo
                3 - Exibir Dados do Aluguel
                4 - Exibir Dados do Veículo
                5 - Calcular Aluguel
                0 - Sair
                """;
            String entrada = io.entradaDados(menu);
            opcao = conversor.stringToInt(entrada);
            avaliarOpcaoEscolhida();
        } while (opcao != 0);
    }

    public void avaliarOpcaoEscolhida() {
        switch (opcao) {
            case 1 -> {
                double vDia = conversor.stringToDouble(io.entradaDados("Valor do dia:"));
                int nDias = conversor.stringToInt(io.entradaDados("Número de dias:"));
                double kRodado = conversor.stringToDouble(io.entradaDados("Quilômetros rodados:"));
                double vKm = conversor.stringToDouble(io.entradaDados("Valor por Km rodado:"));
                alugarVeiculo.cadastrarAluguel(vDia, nDias, kRodado, vKm);
            }
            case 2 -> {
                String modelo = io.entradaDados("Modelo do veículo:");
                int ano = conversor.stringToInt(io.entradaDados("Ano de fabricação:"));
                veiculo.cadastrarVeiculo(modelo, ano);
            }
            case 3 -> alugarVeiculo.listarAluguel();
            case 4 -> veiculo.exibirDadosVeiculo();
            case 5 -> {
                custos.calcularAluguel(alugarVeiculo);
                io.saidaDados("Total do Aluguel: R$" + custos.totalAluguel);
            }
            case 0 -> io.saidaDados("Encerrando o programa...");
            default -> io.saidaDados("Opção inválida.");
        }
    }
}