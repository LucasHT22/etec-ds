package Carros;


public class ConversorNumeros {
    public int stringToInt(String numero) {
        return Integer.parseInt(numero);
    }

    public double stringToDouble(String numero) {
        return Double.parseDouble(numero);
    }
}