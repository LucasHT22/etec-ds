package Carros;


public class CustoAluguelVeiculo {
    double totalAluguel;

    public void calcularAluguel(AlugarVeiculo aluguel) {
        totalAluguel = (aluguel.valorDia * aluguel.numeroDias) +
                       (aluguel.quilometrosRodados * aluguel.valorKilometroRodado);
    }
}