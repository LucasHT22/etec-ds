package Carros;

public class CadastrarVeiculo {
    private String modelo;
    private int anoFab;

    public void cadastrarVeiculo(String mod, int anoF) {
        modelo = mod;
        anoFab = anoF;
    }

    public void exibirDadosVeiculo() {
        String dados = String.format("""
            Veículo:
            Modelo: %s
            Ano de Fabricação: %d
            """, modelo, anoFab);
        new EntradaSaidaDados().saidaDados(dados);
    }
}