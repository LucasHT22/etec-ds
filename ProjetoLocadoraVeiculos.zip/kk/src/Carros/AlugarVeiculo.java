package Carros;

public class AlugarVeiculo {
    double valorDia;
    int numeroDias;
    double quilometrosRodados;
    double valorKilometroRodado;

    public void cadastrarAluguel(double vDia, int nDias, double kRodados, double vKilometro) {
        valorDia = vDia;
        numeroDias = nDias;
        quilometrosRodados = kRodados;
        valorKilometroRodado = vKilometro;
    }

    public void listarAluguel() {
        String dados = String.format("""
            Aluguel:
            Valor por Dia: R$%.2f
            Número de Dias: %d
            Km Rodados: %.2f
            Valor por Km: R$%.2f
            """, valorDia, numeroDias, quilometrosRodados, valorKilometroRodado);
        new EntradaSaidaDados().saidaDados(dados);
    }
}