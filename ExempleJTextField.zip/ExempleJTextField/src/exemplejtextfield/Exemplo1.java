package exemplejtextfield;

import javax.swing.JFrame;

public class Exemplo1 extends JFrame{
    public Exemplo1() {
        super("Como abrir janela maximizada");
        setSize(300, 150);
        setVisible(true);
        setExtendedState(MAXIMIZED_BOTH);
    }
}
