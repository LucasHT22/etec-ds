package exemplejtextfield;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class ExemploJTextField extends JFrame{ 
    JLabel rotulo, rotulo1, rotulo2, rotulo3, rotulo4, rotulo5, rotulo6, rotulo7;
    JTextField texto1, texto2, texto3, texto4, texto5, texto6, texto7;
    public ExemploJTextField() {
        super("Exemplo com JTextField");
        Container tela = getContentPane();
        setLayout(null);
        
        rotulo = new JLabel("Cadastro Cliente");
        rotulo1 = new JLabel("Nome:");
        rotulo2 = new JLabel("CPF:");
        rotulo3 = new JLabel("RG:");
        rotulo4 = new JLabel("Endereço:");
        rotulo5 = new JLabel("Cidade:");
        rotulo6 = new JLabel("Estado:");
        rotulo7 = new JLabel("CEP:");
        
        texto1 = new JTextField(37);
        texto2 = new JTextField(15);
        texto3 = new JTextField(10);
        texto4 = new JTextField(37);
        texto5 = new JTextField(37);
        texto6 = new JTextField(37);
        texto7 = new JTextField(9);
        
        rotulo.setBounds(120,20,300,50);
        rotulo1.setBounds(50,60,80,20);
        rotulo2.setBounds(50,100,80,20);
        rotulo3.setBounds(50,140,80,20);
        rotulo4.setBounds(50,180,80,20);
        rotulo5.setBounds(50,220,80,20);
        rotulo6.setBounds(50,260,80,20);
        rotulo7.setBounds(50,300,80,20);
      
        texto1.setBounds(50,80,200,20);
        texto2.setBounds(50,120,100,20);
        texto3.setBounds(50,160,80,20);
        texto4.setBounds(50,200,80,20);
        texto5.setBounds(50,240,200,20);
        texto6.setBounds(50,280,100,20);
        texto7.setBounds(50,320,80,20);
        
        rotulo.setForeground(Color.red);
        rotulo.setFont(new Font("Arial",Font.BOLD,20));
        
        tela.add(rotulo);
        tela.add(rotulo1);
        tela.add(rotulo2);
        tela.add(rotulo3);
        tela.add(rotulo4);
        tela.add(rotulo5);
        tela.add(rotulo6);
        tela.add(rotulo7);
        tela.add(texto1);
        tela.add(texto2);
        tela.add(texto3);
        tela.add(texto4);
        tela.add(texto5);
        tela.add(texto6);
        tela.add(texto7);
        
        tela.setBackground(Color.gray);
        setSize(400,400);
        setVisible(true);
        setLocationRelativeTo(null);
    }
}
