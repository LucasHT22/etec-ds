package exemplejtextfield;

import javax.swing.JFrame;

public class Exemplo4 extends JFrame{
    public Exemplo4() {
        super("Janela centralizada");
        setSize(300, 150);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
