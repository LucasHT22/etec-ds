package exemplejtextfield;

import javax.swing.JFrame;

public class Exemplo3 extends JFrame{
    public Exemplo3() {
        super("Uma janela não dimensinável");
        setSize(300, 150);
        setResizable(false);
        setVisible(true);
    }
}