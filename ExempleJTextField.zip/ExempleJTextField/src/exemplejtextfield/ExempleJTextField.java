package exemplejtextfield;

import javax.swing.JFrame;

public class ExempleJTextField {

    public static void main(String[] args) {
        ExemploJTextField app = new ExemploJTextField();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
