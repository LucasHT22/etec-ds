package exemplejtextfield;

import javax.swing.JFrame;

public class ExempleJTextField {

    public static void main(String[] args) {
        ExemploJList app = new ExemploJList();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
