package exemplejtextfield;

import javax.swing.JFrame;

public class ExempleJTextField {

    public static void main(String[] args) {
        ExemploBotao app = new ExemploBotao();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
