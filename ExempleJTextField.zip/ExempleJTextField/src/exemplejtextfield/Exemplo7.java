package exemplejtextfield;

import javax.swing.*;
import java.awt.*;

public class Exemplo7 extends JFrame{
    public Exemplo7() {
        super("Definindo ícone");
        setSize(400,400);
        setLocationRelativeTo(null);
        Container tela = getContentPane();
        tela.setBackground(Color.BLUE);
        ImageIcon icone = new ImageIcon("abrir.png");
        setIconImage(icone.getImage());
        setVisible(true);
    }
}
