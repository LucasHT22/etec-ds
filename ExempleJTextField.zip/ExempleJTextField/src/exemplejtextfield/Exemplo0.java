package exemplejtextfield;

import javax.swing.JFrame;

public class Exemplo0 extends JFrame{
    public Exemplo0() {
        super("Nossa primeira janela");
        setSize(300, 150);
        setVisible(true);
    }
}
