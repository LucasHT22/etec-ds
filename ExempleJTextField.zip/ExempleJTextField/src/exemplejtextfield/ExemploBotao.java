package exemplejtextfield;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class ExemploBotao extends JFrame{
    JButton botaoa,botaob,botaoc;
    ImageIcon icone;
    public ExemploBotao(){
        super("Exemplo com JButton");
        Container tela = getContentPane();
        setLayout(null);
        icone = new ImageIcon("abrir.png");
        
        botaoa = new JButton("Novo");
        botaob = new JButton("Abrir",icone);
        botaoc = new JButton(icone);
        botaoa.setBounds(90, 20, 100, 20);
        botaob.setBounds(90, 50, 100, 20);
        botaoc.setBounds(90, 80, 100, 20);
        
        tela.add(botaoa);
        tela.add(botaob);
        tela.add(botaoc);
        setSize(300,150);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
