package exemplejtextfield;

import javax.swing.JFrame;

public class Exemplo2 extends JFrame{
    public Exemplo2() {
        super("Como abrir janela minimizada");
        setSize(300, 150);
        setVisible(true);
        setExtendedState(ICONIFIED);
    }
}