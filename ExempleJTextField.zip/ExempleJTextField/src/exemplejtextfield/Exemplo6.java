package exemplejtextfield;

import javax.swing.JFrame;
import java.awt.*;

public class Exemplo6 extends JFrame {
    public Exemplo6() {
        super("Definindo cor de fundo RGB");
        Container tela = getContentPane();
        tela.setBackground(new Color(000,000,255));
        setSize(500,300);
        setVisible(true);
    }
}
