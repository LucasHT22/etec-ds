package exemplejtextfield;

import javax.swing.JFrame;
import java.awt.*;

public class Exemplo5 extends JFrame{
    public Exemplo5() {
        super("Definindo cor de fundo");
        Container tela = getContentPane();
        tela.setBackground(Color.blue);
        setSize(500,300);
        setVisible(true);
    }
}
