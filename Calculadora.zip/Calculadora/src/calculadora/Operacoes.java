package calculadora;

import javax.swing .*;
import java.awt .*;
import java.awt.event .*;

public class Operacoes extends JFrame {
    JLabel rotulo1, rotulo2,exibir;
    JTextField texto1, texto2;
    JButton somar, subtrair, multiplicar, dividir;
    
    public Operacoes() {
        super("Calculadora");
        Container tela = getContentPane();
        setLayout(null);
        rotulo1 = new JLabel("1° Numero: ");
        rotulo2 = new JLabel("2° Numero: ");
        
        texto1 = new JTextField(5);
        texto2 = new JTextField(5);
        
        exibir = new JLabel("");
        somar = new JButton("+");
        subtrair = new JButton("-");
        multiplicar = new JButton("*");
        dividir = new JButton("/");

        rotulo1.setBounds(50,20,100,20);
        rotulo2.setBounds(50,60,100,20);
        rotulo1.setForeground(Color.WHITE);
        rotulo2.setForeground(Color.WHITE);
        
        texto1.setBounds(120,20,200,20); 
        texto2.setBounds(120,60,200,20);
        texto1.setForeground(Color.BLACK);
        texto2.setForeground(Color.BLACK);
        
        somar.setBounds(50,100,50,20);
        subtrair.setBounds(115, 100, 50, 20);
        multiplicar.setBounds(180, 100, 50, 20);
        dividir.setBounds(245, 100, 50, 20);
        
        somar.setBackground(new Color(255, 159, 10));
        subtrair.setBackground(new Color(255, 159, 10));
        multiplicar.setBackground(new Color(255, 159, 10));
        dividir.setBackground(new Color(255, 159, 10));
        
        somar.setForeground(Color.WHITE);
        subtrair.setForeground(Color.WHITE);
        multiplicar.setForeground(Color.WHITE);
        dividir.setForeground(Color.WHITE);
        
        somar.setBorderPainted(false);
        subtrair.setBorderPainted(false);
        multiplicar.setBorderPainted(false);
        dividir.setBorderPainted(false);
        
        exibir.setBounds(50,140,300,30);
        exibir.setForeground(Color.WHITE);
        exibir.setFont(new Font("Arial", Font.PLAIN, 30));
        
        somar.addActionListener(
            new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    double numero1, numero2, soma;
                    soma = 0;
                    numero1 = Double.parseDouble(texto1.getText());
                    numero2 = Double.parseDouble(texto2.getText());
                    soma = numero1 + numero2;
                    exibir.setVisible(true);
                    exibir.setText(numero1 + " + " + numero2 + " = " + soma);
                }
            }
        );
        subtrair.addActionListener(
            new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    double numero1, numero2, subtrair;
                    subtrair = 0;
                    numero1 = Double.parseDouble(texto1.getText());
                    numero2 = Double.parseDouble(texto2.getText());
                    subtrair = numero1 - numero2;
                    exibir.setVisible(true);
                    exibir.setText(numero1 + " - " + numero2 + " = " + subtrair);
                }
            }
        );
        multiplicar.addActionListener(
            new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    double numero1, numero2, multiplicar;
                    multiplicar = 0;
                    numero1 = Double.parseDouble(texto1.getText());
                    numero2 = Double.parseDouble(texto2.getText());
                    multiplicar = numero1 * numero2;
                    exibir.setVisible(true);
                    exibir.setText(numero1 + " * " + numero2 + " = " + multiplicar);
                }
            }
        );
        dividir.addActionListener(
            new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    double numero1, numero2, dividir;
                    dividir = 0;
                    numero1 = Double.parseDouble(texto1.getText());
                    numero2 = Double.parseDouble(texto2.getText());
                    dividir = numero1 / numero2;
                    exibir.setVisible(true);
                    exibir.setText(numero1 + " / " + numero2 + " = " + dividir);
                }
            }
        );

        exibir.setVisible(false);

        tela.add(rotulo1);
        tela.add(rotulo2);
        tela.add(texto1);
        tela.add(texto2);
        tela.add(exibir);
        tela.add(somar);
        tela.add(subtrair);
        tela.add(multiplicar);
        tela.add(dividir);
        tela.setBackground(Color.BLACK);
            
        setSize(400, 250);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }  
}
