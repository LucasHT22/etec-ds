package calculadora;

import javax.swing.JFrame;

public class Calculadora {
    public static void main(String[] args) {
        Operacoes app = new Operacoes();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
