package view;

import dao.ClienteDAO;
import model.Cliente;
import util.ValidadorCPF;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.Period;

/**
 * Frame para cadastro de clientes com validações
 * @author lucas
 */
public class CadastrarClienteFrame extends JFrame {
    private JTextField campoNome;
    private JFormattedTextField campoCpf;
    private JFormattedTextField campoTelefone;
    private JTextField campoEmail;
    private JTextArea campoEndereco;
    private JFormattedTextField campoCnh;
    private JFormattedTextField campoDataNascimento;
    private JTextArea campoObservacoes;
    private JButton botaoCadastrar;
    private JButton botaoLimpar;
    private JLabel lblStatus;
    
    private ClienteDAO clienteDAO;

    public CadastrarClienteFrame() {
        this.clienteDAO = new ClienteDAO();
        initializeComponents();
        setupLayout();
        setupEvents();
        setVisible(true);
    }

    private void initializeComponents() {
        setTitle("Cadastrar Cliente");
        setSize(500, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        
        // Campos básicos
        campoNome = new JTextField(20);
        campoEmail = new JTextField(20);
        campoEndereco = new JTextArea(3, 20);
        campoEndereco.setLineWrap(true);
        campoEndereco.setWrapStyleWord(true);
        
        campoObservacoes = new JTextArea(3, 20);
        campoObservacoes.setLineWrap(true);
        campoObservacoes.setWrapStyleWord(true);
        
        // Campos com máscara
        try {
            MaskFormatter cpfFormatter = new MaskFormatter("###.###.###-##");
            cpfFormatter.setPlaceholderCharacter('_');
            campoCpf = new JFormattedTextField(cpfFormatter);
            
            MaskFormatter telFormatter = new MaskFormatter("(##) #####-####");
            telFormatter.setPlaceholderCharacter('_');
            campoTelefone = new JFormattedTextField(telFormatter);
            
            MaskFormatter cnhFormatter = new MaskFormatter("###########");
            cnhFormatter.setPlaceholderCharacter('_');
            campoCnh = new JFormattedTextField(cnhFormatter);
            
            MaskFormatter dataFormatter = new MaskFormatter("##/##/####");
            dataFormatter.setPlaceholderCharacter('_');
            campoDataNascimento = new JFormattedTextField(dataFormatter);
            
        } catch (ParseException e) {
            // Fallback para campos sem máscara
            campoCpf = new JFormattedTextField();
            campoTelefone = new JFormattedTextField();
            campoCnh = new JFormattedTextField();
            campoDataNascimento = new JFormattedTextField();
        }
        
        // Botões
        botaoCadastrar = new JButton("Cadastrar");
        botaoLimpar = new JButton("Limpar");
        lblStatus = new JLabel(" ");
        
        // Estilização
        botaoCadastrar.setBackground(new Color(34, 139, 34));
        botaoCadastrar.setForeground(Color.WHITE);
        botaoCadastrar.setFocusPainted(false);
        
        botaoLimpar.setBackground(new Color(255, 140, 0));
        botaoLimpar.setForeground(Color.WHITE);
        botaoLimpar.setFocusPainted(false);
        
        lblStatus.setHorizontalAlignment(SwingConstants.CENTER);
    }

    private void setupLayout() {
        setLayout(new BorderLayout());
        
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Título
        JLabel titleLabel = new JLabel("Cadastro de Cliente");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(titleLabel, gbc);
        
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        
        // Nome
        gbc.gridx = 0; gbc.gridy = 1;
        mainPanel.add(new JLabel("Nome Completo: *"), gbc);
        gbc.gridx = 1;
        mainPanel.add(campoNome, gbc);
        
        // CPF
        gbc.gridx = 0; gbc.gridy = 2;
        mainPanel.add(new JLabel("CPF: *"), gbc);
        gbc.gridx = 1;
        mainPanel.add(campoCpf, gbc);
        
        // Telefone
        gbc.gridx = 0; gbc.gridy = 3;
        mainPanel.add(new JLabel("Telefone: *"), gbc);
        gbc.gridx = 1;
        mainPanel.add(campoTelefone, gbc);
        
        // Email
        gbc.gridx = 0; gbc.gridy = 4;
        mainPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(campoEmail, gbc);
        
        // CNH
        gbc.gridx = 0; gbc.gridy = 5;
        mainPanel.add(new JLabel("CNH:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(campoCnh, gbc);
        
        // Data de Nascimento
        gbc.gridx = 0; gbc.gridy = 6;
        mainPanel.add(new JLabel("Data Nascimento:"), gbc);
        gbc.gridx = 1;
        mainPanel.add(campoDataNascimento, gbc);
        
        // Endereço
        gbc.gridx = 0; gbc.gridy = 7;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        mainPanel.add(new JLabel("Endereço:"), gbc);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        JScrollPane scrollEndereco = new JScrollPane(campoEndereco);
        scrollEndereco.setPreferredSize(new Dimension(200, 60));
        mainPanel.add(scrollEndereco, gbc);
        
        // Observações
        gbc.gridx = 0; gbc.gridy = 8;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        mainPanel.add(new JLabel("Observações:"), gbc);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        JScrollPane scrollObs = new JScrollPane(campoObservacoes);
        scrollObs.setPreferredSize(new Dimension(200, 60));
        mainPanel.add(scrollObs, gbc);
        
        // Botões
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(botaoCadastrar);
        buttonPanel.add(botaoLimpar);
        
        gbc.gridx = 0; gbc.gridy = 9; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(buttonPanel, gbc);
        
        // Status
        gbc.gridy = 10;
        mainPanel.add(lblStatus, gbc);
        
        // Nota
        JLabel notaLabel = new JLabel("* Campos obrigatórios");
        notaLabel.setFont(new Font("Arial", Font.ITALIC, 10));
        notaLabel.setForeground(Color.GRAY);
        gbc.gridy = 11;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(notaLabel, gbc);
        
        add(mainPanel, BorderLayout.CENTER);
    }

    private void setupEvents() {
        botaoCadastrar.addActionListener(e -> cadastrarCliente());
        botaoLimpar.addActionListener(e -> limparCampos());
        
        // Adicionando Enter nos campos principais
        campoNome.addActionListener(e -> campoCpf.requestFocus());
        campoCpf.addActionListener(e -> campoTelefone.requestFocus());
        campoTelefone.addActionListener(e -> botaoCadastrar.doClick());
    }

    private void cadastrarCliente() {
        try {
            if (!validarCampos()) {
                return;
            }
            
            // Verificar se CPF já existe
            String cpfLimpo = ValidadorCPF.limparCPF(campoCpf.getText());
            Cliente clienteExistente = clienteDAO.buscarPorCpf(cpfLimpo);
            if (clienteExistente != null) {
                mostrarErro("CPF já cadastrado no sistema!");
                campoCpf.requestFocus();
                return;
            }
            
            String nome = campoNome.getText().trim();
            String cpf = cpfLimpo;
            String telefone = campoTelefone.getText().replaceAll("[()-\\s]", "");
            String email = campoEmail.getText().trim();
            String endereco = campoEndereco.getText().trim();
            String cnh = campoCnh.getText().replaceAll("[^0-9]", "");
            String observacoes = campoObservacoes.getText().trim();
            
            // Converter data de nascimento para LocalDate
            LocalDate dataNascimento = null;
            String dataTexto = campoDataNascimento.getText().replaceAll("[/_]", "");
            if (!dataTexto.isEmpty() && dataTexto.length() == 8) {
                try {
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMyyyy");
                    dataNascimento = LocalDate.parse(dataTexto, formatter);
                } catch (DateTimeParseException ex) {
                    mostrarErro("Data de nascimento inválida!");
                    campoDataNascimento.requestFocus();
                    return;
                }
            }
            
            // Criar cliente
            Cliente cliente = new Cliente();
            cliente.setNome(nome);
            cliente.setCpf(cpf);
            cliente.setTelefone(telefone);
            cliente.setEmail(email.isEmpty() ? null : email);
            cliente.setEndereco(endereco.isEmpty() ? null : endereco);
            cliente.setCnh(cnh.isEmpty() ? null : cnh);
            cliente.setDataNascimento(dataNascimento);
            cliente.setObservacoes(observacoes.isEmpty() ? null : observacoes);
            
            // Inserir no banco
            clienteDAO.inserir(cliente);
            
            mostrarSucesso("Cliente cadastrado com sucesso!");
            limparCampos();
            
        } catch (Exception ex) {
            mostrarErro("Erro ao cadastrar cliente: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private boolean validarCampos() {
        String nome = campoNome.getText().trim();
        String cpf = ValidadorCPF.limparCPF(campoCpf.getText());
        String telefone = campoTelefone.getText().replaceAll("[()-\\s]", "");
        String cnh = campoCnh.getText().replaceAll("[^0-9]", "");
        String dataNasc = campoDataNascimento.getText().replaceAll("[/_]", "");
        
        // Validação do nome
        if (nome.isEmpty()) {
            mostrarErro("Nome é obrigatório!");
            campoNome.requestFocus();
            return false;
        }
        
        if (nome.length() < 3) {
            mostrarErro("Nome deve ter pelo menos 3 caracteres!");
            campoNome.requestFocus();
            return false;
        }
        
        // Validação do CPF
        if (cpf.length() != 11) {
            mostrarErro("CPF deve ter 11 dígitos!");
            campoCpf.requestFocus();
            return false;
        }
        
        if (!ValidadorCPF.isValid(cpf)) {
            mostrarErro("CPF inválido!");
            campoCpf.requestFocus();
            return false;
        }
        
        // Validação do telefone
        if (telefone.length() != 11) {
            mostrarErro("Telefone deve ter 11 dígitos!");
            campoTelefone.requestFocus();
            return false;
        }
        
        // Validação da CNH (não obrigatória)
        if (!cnh.isEmpty() && cnh.length() != 11) {
            mostrarErro("CNH deve ter 11 dígitos!");
            campoCnh.requestFocus();
            return false;
        }
        
        // Validação da data de nascimento (não obrigatória)
        if (!dataNasc.isEmpty()) {
            if (dataNasc.length() != 8) {
                mostrarErro("Data de nascimento deve ter formato DD/MM/AAAA!");
                campoDataNascimento.requestFocus();
                return false;
            }
            
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMyyyy");
                LocalDate dataNascimento = LocalDate.parse(dataNasc, formatter);
                LocalDate hoje = LocalDate.now();
                
                Period idade = Period.between(dataNascimento, hoje);
                
                if (idade.getYears() < 18) {
                    mostrarErro("Cliente deve ter pelo menos 18 anos!");
                    campoDataNascimento.requestFocus();
                    return false;
                }
                
                if (idade.getYears() > 120) {
                    mostrarErro("Data de nascimento inválida!");
                    campoDataNascimento.requestFocus();
                    return false;
                }
                
            } catch (DateTimeParseException e) {
                mostrarErro("Data de nascimento inválida!");
                campoDataNascimento.requestFocus();
                return false;
            }
        }
        
        // Validação do email (se preenchido)
        String email = campoEmail.getText().trim();
        if (!email.isEmpty() && !isEmailValido(email)) {
            mostrarErro("Email inválido!");
            campoEmail.requestFocus();
            return false;
        }
        
        return true;
    }

    private boolean isEmailValido(String email) {
        return email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
    }

    private void limparCampos() {
        campoNome.setText("");
        campoCpf.setText("");
        campoTelefone.setText("");
        campoEmail.setText("");
        campoEndereco.setText("");
        campoCnh.setText("");
        campoDataNascimento.setText("");
        campoObservacoes.setText("");
        lblStatus.setText(" ");
        campoNome.requestFocus();
    }

    private void mostrarSucesso(String mensagem) {
        lblStatus.setText(mensagem);
        lblStatus.setForeground(new Color(34, 139, 34));
        
        Timer timer = new Timer(3000, e -> lblStatus.setText(" "));
        timer.setRepeats(false);
        timer.start();
    }

    private void mostrarErro(String mensagem) {
        lblStatus.setText(mensagem);
        lblStatus.setForeground(Color.RED);
        
        Timer timer = new Timer(4000, e -> lblStatus.setText(" "));
        timer.setRepeats(false);
        timer.start();
    }
}