package view;

import dao.LocacaoDAO;
import dao.VeiculoDAO;
import dao.ClienteDAO;
import model.Locacao;
import model.Veiculo;
import model.Cliente;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Frame para exibição de relatórios do sistema
 * @author lucas
 */
public class RelatoriosFrame extends JFrame {
    private JTabbedPane abas;
    private LocacaoDAO locacaoDAO;
    private VeiculoDAO veiculoDAO;
    private ClienteDAO clienteDAO;
    private DecimalFormat formatoMoeda;

    public RelatoriosFrame() {
        this.locacaoDAO = new LocacaoDAO();
        this.veiculoDAO = new VeiculoDAO();
        this.clienteDAO = new ClienteDAO();
        this.formatoMoeda = new DecimalFormat("R$ #,##0.00");
        
        inicializarComponentes();
        carregarRelatorios();
        setVisible(true);
    }

    private void inicializarComponentes() {
        setTitle("Relatórios do Sistema");
        setSize(900, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        abas = new JTabbedPane();
        
        // Aba 1: Locações Ativas
        abas.addTab("Locações Ativas", criarPainelLocacoesAtivas());
        
        // Aba 2: Histórico de Locações
        abas.addTab("Histórico", criarPainelHistorico());
        
        // Aba 3: Veículos por Status
        abas.addTab("Status Veículos", criarPainelStatusVeiculos());
        
        // Aba 4: Clientes Frequentes
        abas.addTab("Clientes", criarPainelClientes());
        
        // Aba 5: Resumo Financeiro
        abas.addTab("Financeiro", criarPainelFinanceiro());
        
        add(abas, BorderLayout.CENTER);
        
        // Painel de botões
        JPanel painelBotoes = new JPanel(new FlowLayout());
        JButton btnAtualizar = new JButton("Atualizar Relatórios");
        JButton btnFechar = new JButton("Fechar");
        
        btnAtualizar.addActionListener(e -> carregarRelatorios());
        btnFechar.addActionListener(e -> dispose());
        
        painelBotoes.add(btnAtualizar);
        painelBotoes.add(btnFechar);
        
        add(painelBotoes, BorderLayout.SOUTH);
    }

    private JPanel criarPainelLocacoesAtivas() {
        JPanel painel = new JPanel(new BorderLayout());
        
        String[] colunas = {"ID", "Cliente", "Veículo", "Placa", "Data Início", "Data Fim Prevista", "Dias", "Valor Total"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable tabela = new JTable(modelo);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scroll = new JScrollPane(tabela);
        painel.add(scroll, BorderLayout.CENTER);
        
        // Painel de informações
        JPanel painelInfo = new JPanel(new FlowLayout());
        JLabel lblTotalAtivas = new JLabel("Total de locações ativas: 0");
        painelInfo.add(lblTotalAtivas);
        painel.add(painelInfo, BorderLayout.SOUTH);
        
        painel.putClientProperty("tabela", tabela);
        painel.putClientProperty("modelo", modelo);
        painel.putClientProperty("lblTotal", lblTotalAtivas);
        
        return painel;
    }

    private JPanel criarPainelHistorico() {
        JPanel painel = new JPanel(new BorderLayout());
        
        // Painel de filtros
        JPanel painelFiltros = new JPanel(new FlowLayout());
        painelFiltros.setBorder(BorderFactory.createTitledBorder("Filtros"));
        
        JComboBox<String> comboStatus = new JComboBox<>(new String[]{"Todas", "Devolvidas", "Atrasadas"});
        JTextField txtDataInicio = new JTextField(10);
        JTextField txtDataFim = new JTextField(10);
        JButton btnFiltrar = new JButton("Filtrar");
        
        painelFiltros.add(new JLabel("Status:"));
        painelFiltros.add(comboStatus);
        painelFiltros.add(new JLabel("De:"));
        painelFiltros.add(txtDataInicio);
        painelFiltros.add(new JLabel("Até:"));
        painelFiltros.add(txtDataFim);
        painelFiltros.add(btnFiltrar);
        
        // Tabela
        String[] colunas = {"ID", "Cliente", "Veículo", "Início", "Fim Prevista", "Fim Real", "Status", "Valor"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable tabela = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabela);
        
        painel.add(painelFiltros, BorderLayout.NORTH);
        painel.add(scroll, BorderLayout.CENTER);
        
        painel.putClientProperty("tabela", tabela);
        painel.putClientProperty("modelo", modelo);
        
        return painel;
    }

    private JPanel criarPainelStatusVeiculos() {
        JPanel painel = new JPanel(new BorderLayout());
        
        String[] colunas = {"ID", "Modelo", "Marca", "Placa", "Status", "Km Atual", "Valor Diária"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable tabela = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabela);
        
        // Painel de estatísticas
        JPanel painelStats = new JPanel(new GridLayout(1, 4, 10, 10));
        painelStats.setBorder(BorderFactory.createTitledBorder("Estatísticas"));
        
        JLabel lblDisponiveis = new JLabel("Disponíveis: 0", SwingConstants.CENTER);
        JLabel lblAlugados = new JLabel("Alugados: 0", SwingConstants.CENTER);
        JLabel lblManutencao = new JLabel("Manutenção: 0", SwingConstants.CENTER);
        JLabel lblTotal = new JLabel("Total: 0", SwingConstants.CENTER);
        
        lblDisponiveis.setForeground(new Color(34, 139, 34));
        lblAlugados.setForeground(new Color(255, 140, 0));
        lblManutencao.setForeground(Color.RED);
        lblTotal.setForeground(Color.BLUE);
        
        painelStats.add(lblDisponiveis);
        painelStats.add(lblAlugados);
        painelStats.add(lblManutencao);
        painelStats.add(lblTotal);
        
        painel.add(painelStats, BorderLayout.NORTH);
        painel.add(scroll, BorderLayout.CENTER);
        
        painel.putClientProperty("tabela", tabela);
        painel.putClientProperty("modelo", modelo);
        painel.putClientProperty("lblDisponiveis", lblDisponiveis);
        painel.putClientProperty("lblAlugados", lblAlugados);
        painel.putClientProperty("lblManutencao", lblManutencao);
        painel.putClientProperty("lblTotal", lblTotal);
        
        return painel;
    }

    private JPanel criarPainelClientes() {
        JPanel painel = new JPanel(new BorderLayout());
        
        String[] colunas = {"ID", "Nome", "CPF", "Telefone", "Total Locações", "Última Locação"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable tabela = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabela);
        
        painel.add(scroll, BorderLayout.CENTER);
        
        painel.putClientProperty("tabela", tabela);
        painel.putClientProperty("modelo", modelo);
        
        return painel;
    }

    private JPanel criarPainelFinanceiro() {
        JPanel painel = new JPanel(new BorderLayout());
        
        // Painel de resumo
        JPanel painelResumo = new JPanel(new GridLayout(2, 3, 10, 10));
        painelResumo.setBorder(BorderFactory.createTitledBorder("Resumo Financeiro"));
        
        JLabel lblReceitaTotal = new JLabel("Receita Total: R$ 0,00", SwingConstants.CENTER);
        JLabel lblReceitaMes = new JLabel("Receita do Mês: R$ 0,00", SwingConstants.CENTER);
        JLabel lblMediaDiaria = new JLabel("Média por Dia: R$ 0,00", SwingConstants.CENTER);
        JLabel lblTotalLocacoes = new JLabel("Total de Locações: 0", SwingConstants.CENTER);
        JLabel lblTicketMedio = new JLabel("Ticket Médio: R$ 0,00", SwingConstants.CENTER);
        JLabel lblMultasTotal = new JLabel("Total em Multas: R$ 0,00", SwingConstants.CENTER);
        
        lblReceitaTotal.setForeground(new Color(34, 139, 34));
        lblReceitaMes.setForeground(new Color(34, 139, 34));
        lblMultasTotal.setForeground(Color.RED);
        
        painelResumo.add(lblReceitaTotal);
        painelResumo.add(lblReceitaMes);
        painelResumo.add(lblMediaDiaria);
        painelResumo.add(lblTotalLocacoes);
        painelResumo.add(lblTicketMedio);
        painelResumo.add(lblMultasTotal);
        
        // Tabela de detalhes por mês
        String[] colunas = {"Mês/Ano", "Locações", "Receita", "Multas", "Total"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable tabela = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabela);
        
        painel.add(painelResumo, BorderLayout.NORTH);
        painel.add(scroll, BorderLayout.CENTER);
        
        painel.putClientProperty("tabela", tabela);
        painel.putClientProperty("modelo", modelo);
        painel.putClientProperty("lblReceitaTotal", lblReceitaTotal);
        painel.putClientProperty("lblReceitaMes", lblReceitaMes);
        painel.putClientProperty("lblMediaDiaria", lblMediaDiaria);
        painel.putClientProperty("lblTotalLocacoes", lblTotalLocacoes);
        painel.putClientProperty("lblTicketMedio", lblTicketMedio);
        painel.putClientProperty("lblMultasTotal", lblMultasTotal);
        
        return painel;
    }

    private void carregarRelatorios() {
        try {
            carregarLocacoesAtivas();
            carregarHistorico();
            carregarStatusVeiculos();
            carregarClientes();
            carregarFinanceiro();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Erro ao carregar relatórios: " + e.getMessage(), 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void carregarLocacoesAtivas() {
        JPanel painel = (JPanel) abas.getComponentAt(0);
        DefaultTableModel modelo = (DefaultTableModel) painel.getClientProperty("modelo");
        JLabel lblTotal = (JLabel) painel.getClientProperty("lblTotal");
        
        modelo.setRowCount(0);
        
        List<Locacao> locacoesAtivas = locacaoDAO.listarPorStatus("ativa");
        
        for (Locacao locacao : locacoesAtivas) {
            Cliente cliente = clienteDAO.buscarPorId(locacao.getClienteId());
            Veiculo veiculo = veiculoDAO.buscarPorId(locacao.getVeiculoId());
            
            Object[] linha = {
                locacao.getId(),
                cliente != null ? cliente.getNome() : "N/A",
                veiculo != null ? veiculo.getModelo() : "N/A",
                veiculo != null ? veiculo.getPlaca() : "N/A",
                locacao.getDataInicio().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                locacao.getDataFimPrevista().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                locacao.getDiasPrevistos(),
                formatoMoeda.format(locacao.getValorTotalPrevisto())
            };
            modelo.addRow(linha);
        }
        
        lblTotal.setText("Total de locações ativas: " + locacoesAtivas.size());
    }

    private void carregarHistorico() {
        JPanel painel = (JPanel) abas.getComponentAt(1);
        DefaultTableModel modelo = (DefaultTableModel) painel.getClientProperty("modelo");
        
        modelo.setRowCount(0);
        
        List<Locacao> todasLocacoes = locacaoDAO.listarTodas();
        
        for (Locacao locacao : todasLocacoes) {
            Cliente cliente = clienteDAO.buscarPorId(locacao.getClienteId());
            Veiculo veiculo = veiculoDAO.buscarPorId(locacao.getVeiculoId());
            
            Object[] linha = {
                locacao.getId(),
                cliente != null ? cliente.getNome() : "N/A",
                veiculo != null ? veiculo.getModelo() : "N/A",
                locacao.getDataInicio().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                locacao.getDataFimPrevista().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                locacao.getDataFimReal() != null ? 
                    locacao.getDataFimReal().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) : "N/A",
                locacao.getStatus(),
                formatoMoeda.format(locacao.getValorTotalFinal() != null ? 
                    locacao.getValorTotalFinal() : locacao.getValorTotalPrevisto())
            };
            modelo.addRow(linha);
        }
    }

    private void carregarStatusVeiculos() {
        JPanel painel = (JPanel) abas.getComponentAt(2);
        DefaultTableModel modelo = (DefaultTableModel) painel.getClientProperty("modelo");
        JLabel lblDisponiveis = (JLabel) painel.getClientProperty("lblDisponiveis");
        JLabel lblAlugados = (JLabel) painel.getClientProperty("lblAlugados");
        JLabel lblManutencao = (JLabel) painel.getClientProperty("lblManutencao");
        JLabel lblTotal = (JLabel) painel.getClientProperty("lblTotal");
        
        modelo.setRowCount(0);
        
        List<Veiculo> veiculos = veiculoDAO.listarTodos();
        
        int disponiveis = 0, alugados = 0, manutencao = 0;
        
        for (Veiculo veiculo : veiculos) {
            Object[] linha = {
                veiculo.getId(),
                veiculo.getModelo(),
                veiculo.getMarca(),
                veiculo.getPlaca(),
                veiculo.getStatus(),
                veiculo.getKmAtual(),
                formatoMoeda.format(veiculo.getValorDiaria())
            };
            modelo.addRow(linha);
            
            switch (veiculo.getStatus().toLowerCase()) {
                case "disponivel": disponiveis++; break;
                case "alugado": alugados++; break;
                case "manutencao": manutencao++; break;
            }
        }
        
        lblDisponiveis.setText("Disponíveis: " + disponiveis);
        lblAlugados.setText("Alugados: " + alugados);
        lblManutencao.setText("Manutenção: " + manutencao);
        lblTotal.setText("Total: " + veiculos.size());
    }

    private void carregarClientes() {
        JPanel painel = (JPanel) abas.getComponentAt(3);
        DefaultTableModel modelo = (DefaultTableModel) painel.getClientProperty("modelo");
        
        modelo.setRowCount(0);
        
        List<Cliente> clientes = clienteDAO.listarTodos();
        List<Locacao> todasLocacoes = locacaoDAO.listarTodas();
        
        for (Cliente cliente : clientes) {
            long totalLocacoes = todasLocacoes.stream()
                .filter(l -> l.getClienteId().equals(cliente.getId()))
                .count();
            
            LocalDate ultimaLocacao = todasLocacoes.stream()
                .filter(l -> l.getClienteId().equals(cliente.getId()))
                .map(Locacao::getDataInicio)
                .max(LocalDate::compareTo)
                .orElse(null);
            
            Object[] linha = {
                cliente.getId(),
                cliente.getNome(),
                cliente.getCpf(),
                cliente.getTelefone(),
                totalLocacoes,
                ultimaLocacao != null ? ultimaLocacao.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) : "Nunca"
            };
            modelo.addRow(linha);
        }
    }

    private void carregarFinanceiro() {
        JPanel painel = (JPanel) abas.getComponentAt(4);
        DefaultTableModel modelo = (DefaultTableModel) painel.getClientProperty("modelo");
        JLabel lblReceitaTotal = (JLabel) painel.getClientProperty("lblReceitaTotal");
        JLabel lblReceitaMes = (JLabel) painel.getClientProperty("lblReceitaMes");
        JLabel lblMediaDiaria = (JLabel) painel.getClientProperty("lblMediaDiaria");
        JLabel lblTotalLocacoes = (JLabel) painel.getClientProperty("lblTotalLocacoes");
        JLabel lblTicketMedio = (JLabel) painel.getClientProperty("lblTicketMedio");
        JLabel lblMultasTotal = (JLabel) painel.getClientProperty("lblMultasTotal");
        
        modelo.setRowCount(0);
        
        List<Locacao> todasLocacoes = locacaoDAO.listarTodas();
        
        double receitaTotal = todasLocacoes.stream()
            .mapToDouble(l -> l.getValorTotalFinal() != null ? 
                l.getValorTotalFinal() : l.getValorTotalPrevisto())
            .sum();
        
        double multasTotal = todasLocacoes.stream()
            .mapToDouble(l -> l.getMulta() != null ? l.getMulta() : 0.0)
            .sum();
        
        LocalDate mesAtual = LocalDate.now();
        double receitaMes = todasLocacoes.stream()
            .filter(l -> l.getDataInicio().getMonth() == mesAtual.getMonth() && 
                        l.getDataInicio().getYear() == mesAtual.getYear())
            .mapToDouble(l -> l.getValorTotalFinal() != null ? 
                l.getValorTotalFinal() : l.getValorTotalPrevisto())
            .sum();
        
        double ticketMedio = todasLocacoes.isEmpty() ? 0 : receitaTotal / todasLocacoes.size();
        double mediaDiaria = receitaMes / mesAtual.getDayOfMonth();
        
        lblReceitaTotal.setText("Receita Total: " + formatoMoeda.format(receitaTotal));
        lblReceitaMes.setText("Receita do Mês: " + formatoMoeda.format(receitaMes));
        lblMediaDiaria.setText("Média por Dia: " + formatoMoeda.format(mediaDiaria));
        lblTotalLocacoes.setText("Total de Locações: " + todasLocacoes.size());
        lblTicketMedio.setText("Ticket Médio: " + formatoMoeda.format(ticketMedio));
        lblMultasTotal.setText("Total em Multas: " + formatoMoeda.format(multasTotal));
        
        // Agrupar por mês/ano para a tabela
        Map<String, List<Locacao>> locacoesPorMes = todasLocacoes.stream()
            .collect(Collectors.groupingBy(l -> 
                l.getDataInicio().getMonth().toString() + "/" + l.getDataInicio().getYear()));
        
        for (Map.Entry<String, List<Locacao>> entry : locacoesPorMes.entrySet()) {
            List<Locacao> locacoesMes = entry.getValue();
            double receitaMesEspecifico = locacoesMes.stream()
                .mapToDouble(l -> l.getValorTotalFinal() != null ? 
                    l.getValorTotalFinal() : l.getValorTotalPrevisto())
                .sum();
            double multasMes = locacoesMes.stream()
                .mapToDouble(l -> l.getMulta() != null ? l.getMulta() : 0.0)
                .sum();
            
            Object[] linha = {
                entry.getKey(),
                locacoesMes.size(),
                formatoMoeda.format(receitaMesEspecifico),
                formatoMoeda.format(multasMes),
                formatoMoeda.format(receitaMesEspecifico + multasMes)
            };
            modelo.addRow(linha);
        }
    }
}