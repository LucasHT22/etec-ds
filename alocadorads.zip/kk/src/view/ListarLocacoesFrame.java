/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import dao.LocacaoDAO;
import model.Locacao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 *
 * @author lucas
 */

public class ListarLocacoesFrame extends JFrame {
    public ListarLocacoesFrame() {
        setTitle("Lista de Locações");
        setSize(600, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        String[] colunas = {"ID", "Cliente", "Veículo", "Início", "Fim"};
        DefaultTableModel model = new DefaultTableModel(colunas, 0);

        List<Locacao> locacoes = new LocacaoDAO().listarTodas();
        for (Locacao l : locacoes) {
            model.addRow(new Object[]{l.getId(), l.getClienteId(), l.getVeiculoId(), l.getDataInicio(), l.getDataFim()});
        }

        JTable tabela = new JTable(model);
        JScrollPane scroll = new JScrollPane(tabela);

        getContentPane().add(scroll, BorderLayout.CENTER);
    }
}