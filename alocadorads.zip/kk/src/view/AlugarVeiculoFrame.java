package view;

import dao.ClienteDAO;
import dao.VeiculoDAO;
import dao.LocacaoDAO;
import model.Cliente;
import model.Veiculo;
import model.Locacao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Frame para aluguel de veículos
 * @author lucas
 */
public class AlugarVeiculoFrame extends JFrame {
    private JTextField campoClienteCpf;
    private JButton btnBuscarCliente;
    private JLabel lblClienteNome;
    private JTable tabelaVeiculos;
    private DefaultTableModel modeloTabela;
    private JSpinner spinnerDias;
    private JTextField campoDataInicio;
    private JTextField campoKmInicial;
    private JTextArea campoObservacoes;
    private JLabel lblValorTotal;
    private JButton btnConfirmarAluguel;
    private JButton btnCancelar;
    private JLabel lblStatus;
    
    private Cliente clienteSelecionado;
    private Veiculo veiculoSelecionado;

    public AlugarVeiculoFrame() {
        initializeComponents();
        setupLayout();
        setupEvents();
        carregarVeiculosDisponiveis();
        setVisible(true);
    }

    private void initializeComponents() {
        setTitle("Alugar Veículo");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(true);
        
        // Campos
        campoClienteCpf = new JTextField(15);
        btnBuscarCliente = new JButton("Buscar");
        lblClienteNome = new JLabel("Cliente não selecionado");
        lblClienteNome.setForeground(Color.GRAY);
        
        // Tabela de veículos
        String[] colunas = {"ID", "Modelo", "Marca", "Ano", "Placa", "Cor", "Valor/Dia"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabelaVeiculos = new JTable(modeloTabela);
        tabelaVeiculos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Campos de locação
        spinnerDias = new JSpinner(new SpinnerNumberModel(1, 1, 365, 1));
        campoDataInicio = new JTextField(LocalDate.now().toString());
        campoKmInicial = new JTextField();
        campoObservacoes = new JTextArea(3, 20);
        campoObservacoes.setLineWrap(true);
        campoObservacoes.setWrapStyleWord(true);
        
        lblValorTotal = new JLabel("R$ 0,00");
        lblValorTotal.setFont(new Font("Arial", Font.BOLD, 14));
        lblValorTotal.setForeground(new Color(34, 139, 34));
        
        // Botões
        btnConfirmarAluguel = new JButton("Confirmar Aluguel");
        btnCancelar = new JButton("Cancelar");
        lblStatus = new JLabel(" ");
        
        // Estilização
        btnConfirmarAluguel.setBackground(new Color(34, 139, 34));
        btnConfirmarAluguel.setForeground(Color.WHITE);
        btnConfirmarAluguel.setFocusPainted(false);
        btnConfirmarAluguel.setEnabled(false);
        
        btnCancelar.setBackground(new Color(220, 53, 69));
        btnCancelar.setForeground(Color.WHITE);
        btnCancelar.setFocusPainted(false);
        
        lblStatus.setHorizontalAlignment(SwingConstants.CENTER);
    }

    private void setupLayout() {
        setLayout(new BorderLayout());
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Painel superior - Cliente
        JPanel painelCliente = new JPanel(new FlowLayout(FlowLayout.LEFT));
        painelCliente.setBorder(BorderFactory.createTitledBorder("Selecionar Cliente"));
        painelCliente.add(new JLabel("CPF:"));
        painelCliente.add(campoClienteCpf);
        painelCliente.add(btnBuscarCliente);
        painelCliente.add(new JLabel("Cliente:"));
        painelCliente.add(lblClienteNome);
        
        // Painel central - Veículos
        JPanel painelVeiculos = new JPanel(new BorderLayout());
        painelVeiculos.setBorder(BorderFactory.createTitledBorder("Veículos Disponíveis"));
        JScrollPane scrollVeiculos = new JScrollPane(tabelaVeiculos);
        scrollVeiculos.setPreferredSize(new Dimension(750, 200));
        painelVeiculos.add(scrollVeiculos, BorderLayout.CENTER);
        
        // Painel inferior - Dados da locação
        JPanel painelLocacao = new JPanel(new GridBagLayout());
        painelLocacao.setBorder(BorderFactory.createTitledBorder("Dados da Locação"));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        int row = 0;
        
        gbc.gridx = 0; gbc.gridy = row;
        painelLocacao.add(new JLabel("Data Início:"), gbc);
        gbc.gridx = 1;
        painelLocacao.add(campoDataInicio, gbc);
        
        gbc.gridx = 2;
        painelLocacao.add(new JLabel("Dias:"), gbc);
        gbc.gridx = 3;
        painelLocacao.add(spinnerDias, gbc);
        
        gbc.gridx = 0; gbc.gridy = ++row;
        painelLocacao.add(new JLabel("Km Inicial:"), gbc);
        gbc.gridx = 1;
        painelLocacao.add(campoKmInicial, gbc);
        
        gbc.gridx = 2;
        painelLocacao.add(new JLabel("Valor Total:"), gbc);
        gbc.gridx = 3;
        painelLocacao.add(lblValorTotal, gbc);
        
        gbc.gridx = 0; gbc.gridy = ++row;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        painelLocacao.add(new JLabel("Observações:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 3;
        gbc.anchor = GridBagConstraints.WEST;
        JScrollPane scrollObs = new JScrollPane(campoObservacoes);
        scrollObs.setPreferredSize(new Dimension(300, 60));
        painelLocacao.add(scrollObs, gbc);
        
        // Painel de botões
        JPanel painelBotoes = new JPanel(new FlowLayout());
        painelBotoes.add(btnConfirmarAluguel);
        painelBotoes.add(btnCancelar);
        
        // Montagem final
        mainPanel.add(painelCliente, BorderLayout.NORTH);
        mainPanel.add(painelVeiculos, BorderLayout.CENTER);
        
        JPanel painelInferior = new JPanel(new BorderLayout());
        painelInferior.add(painelLocacao, BorderLayout.CENTER);
        painelInferior.add(painelBotoes, BorderLayout.SOUTH);
        painelInferior.add(lblStatus, BorderLayout.PAGE_END);
        
        mainPanel.add(painelInferior, BorderLayout.SOUTH);
        
        add(mainPanel, BorderLayout.CENTER);
    }

    private void setupEvents() {
        btnBuscarCliente.addActionListener(e -> buscarCliente());
        btnCancelar.addActionListener(e -> dispose());
        btnConfirmarAluguel.addActionListener(e -> confirmarAluguel());
        
        // Seleção de veículo na tabela
        tabelaVeiculos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                selecionarVeiculo();
            }
        });
        
        // Atualizar valor total quando dias mudarem
        spinnerDias.addChangeListener(e -> calcularValorTotal());
    }

    private void buscarCliente() {
        String cpf = campoClienteCpf.getText().trim().replaceAll("[.-]", "");
        
        if (cpf.isEmpty()) {
            mostrarErro("Digite o CPF do cliente!");
            return;
        }
        
        try {
            ClienteDAO dao = new ClienteDAO();
            clienteSelecionado = dao.buscarPorCpf(cpf);
            
            if (clienteSelecionado != null) {
                lblClienteNome.setText(clienteSelecionado.getNome());
                lblClienteNome.setForeground(new Color(34, 139, 34));
                verificarPodeAlugar();
            } else {
                lblClienteNome.setText("Cliente não encontrado");
                lblClienteNome.setForeground(Color.RED);
                clienteSelecionado = null;
                btnConfirmarAluguel.setEnabled(false);
            }
        } catch (Exception ex) {
            mostrarErro("Erro ao buscar cliente: " + ex.getMessage());
        }
    }

    private void carregarVeiculosDisponiveis() {
        try {
            VeiculoDAO dao = new VeiculoDAO();
            // Busca veículos com status "disponivel"
            List<Veiculo> veiculos = dao.listarPorStatus("disponivel");
            
            modeloTabela.setRowCount(0);
            for (Veiculo v : veiculos) {
                Object[] row = {
                    v.getId(),
                    v.getModelo(),
                    v.getMarca(),
                    v.getAno(),
                    v.getPlaca(),
                    v.getCor(),
                    String.format("R$ %.2f", v.getValorDiaria())
                };
                modeloTabela.addRow(row);
            }
        } catch (Exception ex) {
            mostrarErro("Erro ao carregar veículos: " + ex.getMessage());
        }
    }

    private void selecionarVeiculo() {
        int selectedRow = tabelaVeiculos.getSelectedRow();
        if (selectedRow >= 0) {
            try {
                int veiculoId = (Integer) modeloTabela.getValueAt(selectedRow, 0);
                VeiculoDAO dao = new VeiculoDAO();
                veiculoSelecionado = dao.buscarPorId(veiculoId);
                
                if (veiculoSelecionado != null) {
                    // Converte BigDecimal para String para exibição
                    campoKmInicial.setText(veiculoSelecionado.getKmAtual().toString());
                    calcularValorTotal();
                    verificarPodeAlugar();
                }
            } catch (Exception ex) {
                mostrarErro("Erro ao selecionar veículo: " + ex.getMessage());
            }
        }
    }

    private void calcularValorTotal() {
        if (veiculoSelecionado != null && veiculoSelecionado.getValorDiaria() != null) {
            int dias = (Integer) spinnerDias.getValue();
            BigDecimal valorTotal = veiculoSelecionado.getValorDiaria().multiply(new BigDecimal(dias));
            lblValorTotal.setText(String.format("R$ %.2f", valorTotal));
        }
    }

    private void verificarPodeAlugar() {
        boolean podeAlugar = clienteSelecionado != null && veiculoSelecionado != null;
        btnConfirmarAluguel.setEnabled(podeAlugar);
    }

    private void confirmarAluguel() {
        try {
            if (!validarDados()) {
                return;
            }
            
            // Criar locação
            Locacao locacao = new Locacao();
            locacao.setClienteId(clienteSelecionado.getId());
            locacao.setVeiculoId(veiculoSelecionado.getId());
            locacao.setDataInicio(LocalDate.parse(campoDataInicio.getText()));
            
            int dias = (Integer) spinnerDias.getValue();
            locacao.setDataFimPrevista(locacao.getDataInicio().plusDays(dias));
            locacao.setDiasPrevistos(dias);
            
            // Converter para BigDecimal
            BigDecimal kmInicial = new BigDecimal(campoKmInicial.getText());
            locacao.setKmInicial(kmInicial);
            
            locacao.setValorDiaria(veiculoSelecionado.getValorDiaria());
            
            // Calcular valor total previsto usando BigDecimal
            BigDecimal valorTotalPrevisto = veiculoSelecionado.getValorDiaria().multiply(new BigDecimal(dias));
            locacao.setValorTotalPrevisto(valorTotalPrevisto);
            
            locacao.setObservacoesRetirada(campoObservacoes.getText().trim());
            locacao.setStatus("ativa");
            
            // Salvar no banco
            LocacaoDAO locacaoDAO = new LocacaoDAO();
            locacaoDAO.inserir(locacao);
            
            // Atualizar status do veículo para alugado
            VeiculoDAO veiculoDAO = new VeiculoDAO();
            veiculoDAO.atualizarStatus(veiculoSelecionado.getId(), "alugado");
            
            mostrarSucesso("Aluguel registrado com sucesso!");
            
            // Limpar formulário
            limparFormulario();
            carregarVeiculosDisponiveis();
            
        } catch (Exception ex) {
            mostrarErro("Erro ao confirmar aluguel: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private boolean validarDados() {
        if (clienteSelecionado == null) {
            mostrarErro("Selecione um cliente!");
            return false;
        }
        
        if (veiculoSelecionado == null) {
            mostrarErro("Selecione um veículo!");
            return false;
        }
        
        String dataInicio = campoDataInicio.getText().trim();
        if (dataInicio.isEmpty()) {
            mostrarErro("Data de início é obrigatória!");
            return false;
        }
        
        try {
            LocalDate data = LocalDate.parse(dataInicio);
            if (data.isBefore(LocalDate.now())) {
                mostrarErro("Data de início não pode ser anterior a hoje!");
                return false;
            }
        } catch (Exception e) {
            mostrarErro("Data de início inválida! Use o formato: YYYY-MM-DD");
            return false;
        }
        
        String kmInicial = campoKmInicial.getText().trim();
        if (kmInicial.isEmpty()) {
            mostrarErro("Km inicial é obrigatório!");
            return false;
        }
        
        try {
            BigDecimal km = new BigDecimal(kmInicial);
            if (km.compareTo(BigDecimal.ZERO) < 0) {
                mostrarErro("Km inicial não pode ser negativo!");
                return false;
            }
        } catch (NumberFormatException e) {
            mostrarErro("Km inicial deve ser um número válido!");
            return false;
        }
        
        return true;
    }

    private void limparFormulario() {
        campoClienteCpf.setText("");
        lblClienteNome.setText("Cliente não selecionado");
        lblClienteNome.setForeground(Color.GRAY);
        tabelaVeiculos.clearSelection();
        spinnerDias.setValue(1);
        campoDataInicio.setText(LocalDate.now().toString());
        campoKmInicial.setText("");
        campoObservacoes.setText("");
        lblValorTotal.setText("R$ 0,00");
        lblStatus.setText(" ");
        
        clienteSelecionado = null;
        veiculoSelecionado = null;
        btnConfirmarAluguel.setEnabled(false);
    }

    private void mostrarSucesso(String mensagem) {
        lblStatus.setText(mensagem);
        lblStatus.setForeground(new Color(34, 139, 34));
        
        Timer timer = new Timer(3000, e -> lblStatus.setText(" "));
        timer.setRepeats(false);
        timer.start();
    }

    private void mostrarErro(String mensagem) {
        lblStatus.setText(mensagem);
        lblStatus.setForeground(Color.RED);
        
        Timer timer = new Timer(4000, e -> lblStatus.setText(" "));
        timer.setRepeats(false);
        timer.start();
    }
}