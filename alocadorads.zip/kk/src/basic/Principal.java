package basic;

import view.LoginFrame;

public class Principal {
    public static void main(String[] args) {
       new LoginFrame().setVisible(true);
    }
}