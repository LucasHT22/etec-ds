package basic;

import util.EntradaSaidaDados;
import javax.swing.*;
import java.awt.*;

public class CadastrarVeiculo extends JFrame {

    private JTextField campoModelo;
    private JTextField campoAnoFab;
    private JButton botaoCadastrar;
    private JButton botaoExibir;

    private String modelo;
    private int anoFab;

    private EntradaSaidaDados io = new EntradaSaidaDados();

    public CadastrarVeiculo() {
        setTitle("Cadastrar Veículo");
        setSize(350, 180);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        JPanel painel = new JPanel(new GridLayout(3, 2, 10, 10));

        painel.add(new JLabel("Modelo:"));
        campoModelo = new JTextField();
        painel.add(campoModelo);

        painel.add(new JLabel("Ano de Fabricação:"));
        campoAnoFab = new JTextField();
        painel.add(campoAnoFab);

        botaoCadastrar = new JButton("Cadastrar");
        botaoExibir = new JButton("Exibir Dados");

        botaoCadastrar.addActionListener(e -> {
            String mod = campoModelo.getText();
            String anoTexto = campoAnoFab.getText();

            try {
                int ano = Integer.parseInt(anoTexto);
                cadastrarVeiculo(mod, ano);
                io.saidaDados("Veículo cadastrado com sucesso!");
            } catch (NumberFormatException ex) {
                io.saidaDados("Ano inválido! Digite um número inteiro.");
            }
        });

        botaoExibir.addActionListener(e -> exibirDadosVeiculo());

        painel.add(botaoCadastrar);
        painel.add(botaoExibir);

        getContentPane().add(painel, BorderLayout.CENTER);
    }

    public void cadastrarVeiculo(String mod, int anoF) {
        modelo = mod;
        anoFab = anoF;
    }

    public void exibirDadosVeiculo() {
        String dados = String.format("""
            Veículo:
            Modelo: %s
            Ano de Fabricação: %d
            """, modelo, anoFab);
        io.saidaDados(dados);
    }
}
