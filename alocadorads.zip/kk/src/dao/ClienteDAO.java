package dao;

import model.Cliente;
import util.ConnectionFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DATA ACCESS OBJECT para Cliente
 * @author lucas
 */
public class ClienteDAO {
    
    /**
     * Insere um novo cliente
     */
    public void inserir(Cliente c) {
        String sql = "INSERT INTO clientes (nome, cpf, telefone, email, endereco, cnh, " +
                    "data_nascimento, observacoes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, c.getNome());
            stmt.setString(2, c.getCpf());
            stmt.setString(3, c.getTelefone());
            stmt.setString(4, c.getEmail());
            stmt.setString(5, c.getEndereco());
            stmt.setString(6, c.getCnh());
            
            if (c.getDataNascimento() != null) {
                stmt.setDate(7, Date.valueOf(c.getDataNascimento()));
            } else {
                stmt.setNull(7, Types.DATE);
            }
            
            stmt.setString(8, c.getObservacoes());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Lista todos os clientes ativos
     */
    public List<Cliente> listarTodos() {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT * FROM clientes WHERE ativo = true ORDER BY nome";
        
        try (Connection conn = ConnectionFactory.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Cliente c = criarClienteDoResultSet(rs);
                lista.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
    
    /**
     * Busca cliente por ID
     */
    public Cliente buscarPorId(int id) {
        String sql = "SELECT * FROM clientes WHERE id = ? AND ativo = true";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return criarClienteDoResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * Busca cliente por CPF
     */
    public Cliente buscarPorCpf(String cpf) {
        String sql = "SELECT * FROM clientes WHERE cpf = ? AND ativo = true";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, cpf);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return criarClienteDoResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * Busca clientes por nome (parcial)
     */
    public List<Cliente> buscarPorNome(String nome) {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT * FROM clientes WHERE nome ILIKE ? AND ativo = true ORDER BY nome";
        
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, "%" + nome + "%");
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Cliente c = criarClienteDoResultSet(rs);
                lista.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
    
    /**
     * Atualiza dados do cliente
     */
    public void atualizar(Cliente c) {
        String sql = "UPDATE clientes SET nome = ?, cpf = ?, telefone = ?, email = ?, " +
                    "endereco = ?, cnh = ?, data_nascimento = ?, observacoes = ? WHERE id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, c.getNome());
            stmt.setString(2, c.getCpf());
            stmt.setString(3, c.getTelefone());
            stmt.setString(4, c.getEmail());
            stmt.setString(5, c.getEndereco());
            stmt.setString(6, c.getCnh());
            
            if (c.getDataNascimento() != null) {
                stmt.setDate(7, Date.valueOf(c.getDataNascimento()));
            } else {
                stmt.setNull(7, Types.DATE);
            }
            
            stmt.setString(8, c.getObservacoes());
            stmt.setInt(9, c.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Desativa cliente (soft delete)
     */
    public void desativar(int id) {
        String sql = "UPDATE clientes SET ativo = false WHERE id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Método auxiliar para criar objeto Cliente a partir do ResultSet
     */
    private Cliente criarClienteDoResultSet(ResultSet rs) throws SQLException {
        Cliente c = new Cliente();
        c.setId(rs.getInt("id"));
        c.setNome(rs.getString("nome"));
        c.setCpf(rs.getString("cpf"));
        c.setTelefone(rs.getString("telefone"));
        c.setEmail(rs.getString("email"));
        c.setEndereco(rs.getString("endereco"));
        c.setCnh(rs.getString("cnh"));
        
        Date dataNascimento = rs.getDate("data_nascimento");
        if (dataNascimento != null) {
            c.setDataNascimento(dataNascimento.toLocalDate());
        }
        
        c.setAtivo(rs.getBoolean("ativo"));
        
        Timestamp dataCadastro = rs.getTimestamp("data_cadastro");
        if (dataCadastro != null) {
            c.setDataCadastro(dataCadastro.toLocalDateTime());
        }
        
        c.setObservacoes(rs.getString("observacoes"));
        
        return c;
    }
}