package util;

public class ConversorNumeros {
    public int stringToInt(String numero) {
        try {
            return Integer.parseInt(numero.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Número inteiro inválido: " + numero);
        }
    }

    public double stringToDouble(String numero) {
        try {
            return Double.parseDouble(numero.trim().replace(",", "."));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Número decimal inválido: " + numero);
        }
    }
}