package service;

import model.Locacao;
import util.EntradaSaidaDados;

public class CustoAluguelVeiculo {
    private double totalAluguel;
    private EntradaSaidaDados io = new EntradaSaidaDados();

    public void calcularAluguel(Locacao aluguel) {
        totalAluguel = (aluguel.getValorDiaria() * aluguel.getNumeroDias()) +
                       (aluguel.getKmRodados() * aluguel.getValorPorKm());
    }

    public void exibirTotal() {
        io.saidaDados(String.format("Valor Total do Aluguel: R$ %.2f", totalAluguel));
    }

    public void calcularEExibir(Locacao aluguel) {
        calcularAluguel(aluguel);
        exibirTotal();
    }
}