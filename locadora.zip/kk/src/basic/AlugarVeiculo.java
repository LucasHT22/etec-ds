package basic;

import util.EntradaSaidaDados;
import javax.swing.*;
import java.awt.*;

public class AlugarVeiculo extends JFrame {
    private double valorDia;
    private int numeroDias;
    private double quilometrosRodados;
    private double valorKilometroRodado;

    private JTextField campoValorDia;
    private JTextField campoNumeroDias;
    private JTextField campoKmRodados;
    private JTextField campoValorKm;
    private JButton botaoCadastrar;
    private JButton botaoListar;
    private JButton botaoCalcularTotal;

    private EntradaSaidaDados io = new EntradaSaidaDados();

    public AlugarVeiculo() {
        setTitle("Alugar Veículo");
        setSize(400, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        JPanel painel = new JPanel(new GridLayout(7, 2, 5, 5));

        painel.add(new JLabel("Valor por Dia (R$):"));
        campoValorDia = new JTextField();
        painel.add(campoValorDia);

        painel.add(new JLabel("Número de Dias:"));
        campoNumeroDias = new JTextField();
        painel.add(campoNumeroDias);

        painel.add(new JLabel("Km Rodados:"));
        campoKmRodados = new JTextField();
        painel.add(campoKmRodados);

        painel.add(new JLabel("Valor por Km (R$):"));
        campoValorKm = new JTextField();
        painel.add(campoValorKm);

        botaoCadastrar = new JButton("Cadastrar Aluguel");
        botaoListar = new JButton("Listar Aluguel");
        botaoCalcularTotal = new JButton("Calcular Total");

        botaoCadastrar.addActionListener(e -> {
            try {
                double vDia = Double.parseDouble(campoValorDia.getText());
                int nDias = Integer.parseInt(campoNumeroDias.getText());
                double kRodados = Double.parseDouble(campoKmRodados.getText());
                double vKm = Double.parseDouble(campoValorKm.getText());

                cadastrarAluguel(vDia, nDias, kRodados, vKm);
                io.saidaDados("Aluguel cadastrado com sucesso!");
            } catch (NumberFormatException ex) {
                io.saidaDados("Por favor, preencha todos os campos corretamente.");
            }
        });

        botaoListar.addActionListener(e -> listarAluguel());

        botaoCalcularTotal.addActionListener(e -> {
            double total = (valorDia * numeroDias) + (quilometrosRodados * valorKilometroRodado);
            io.saidaDados(String.format("Valor Total do Aluguel: R$ %.2f", total));
        });

        painel.add(botaoCadastrar);
        painel.add(botaoListar);
        painel.add(botaoCalcularTotal);

        getContentPane().add(painel, BorderLayout.CENTER);
    }

    public void cadastrarAluguel(double vDia, int nDias, double kRodados, double vKilometro) {
        valorDia = vDia;
        numeroDias = nDias;
        quilometrosRodados = kRodados;
        valorKilometroRodado = vKilometro;
    }

    public void listarAluguel() {
        String dados = String.format("""
            Aluguel:
            Valor por Dia: R$%.2f
            Número de Dias: %d
            Km Rodados: %.2f
            Valor por Km: R$%.2f
            """, valorDia, numeroDias, quilometrosRodados, valorKilometroRodado);

        io.saidaDados(dados);
    }
    
    public double getValorDia() {
        return valorDia;
    }

    public int getNumeroDias() {
        return numeroDias;
    }

    public double getQuilometrosRodados() {
        return quilometrosRodados;
    }

    public double getValorKilometroRodado() {
        return valorKilometroRodado;
    }
}