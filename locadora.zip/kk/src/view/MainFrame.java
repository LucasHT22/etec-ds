package view;

import model.Usuario;
import basic.CadastrarVeiculo;
import basic.AlugarVeiculo;
import service.CustoAluguelVeiculo;
import javax.swing.*;
import java.awt.event.ActionEvent;

public class MainFrame extends JFrame {
    public MainFrame(Usuario usuario) {
        setTitle("Sistema - Locadora");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.add(new JLabel("Usuário logado: " + usuario.getNome() + " (" + usuario.getTipoUsuario() + ")"));

        if (usuario.getTipoUsuario().equals("admin")) {
            JButton btnCadastrarVeiculo = new JButton("Cadastrar Veículo");
            btnCadastrarVeiculo.addActionListener((ActionEvent e) -> {
                String modelo = new util.EntradaSaidaDados().entradaDados("Modelo do veículo:");
                int ano = Integer.parseInt(new util.EntradaSaidaDados().entradaDados("Ano de fabricação:"));
                CadastrarVeiculo veiculo = new CadastrarVeiculo();
                veiculo.cadastrarVeiculo(modelo, ano);
                veiculo.exibirDadosVeiculo();
            });
            panel.add(btnCadastrarVeiculo);
        } else if (usuario.getTipoUsuario().equals("funcionario")) {
            JButton btnAlugarVeiculo = new JButton("Alugar Veículo");
            btnAlugarVeiculo.addActionListener((ActionEvent e) -> {
                AlugarVeiculo aluguel = new AlugarVeiculo();

                double vDia = Double.parseDouble(new util.EntradaSaidaDados().entradaDados("Valor por dia:"));
                int nDias = Integer.parseInt(new util.EntradaSaidaDados().entradaDados("Número de dias:"));
                double km = Double.parseDouble(new util.EntradaSaidaDados().entradaDados("Km rodados:"));
                double vKm = Double.parseDouble(new util.EntradaSaidaDados().entradaDados("Valor por Km:"));

                aluguel.cadastrarAluguel(vDia, nDias, km, vKm);
                aluguel.listarAluguel();

                CustoAluguelVeiculo custo = new CustoAluguelVeiculo();
                // custo.calcularEExibir(aluguel);
            });
            panel.add(btnAlugarVeiculo);
        }

        add(panel);
    }
}
