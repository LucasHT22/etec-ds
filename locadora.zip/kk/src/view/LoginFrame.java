/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import dao.UsuarioDAO;
import model.Usuario;

import javax.swing.*;

/**
 *
 * @author lucas
 */

public class LoginFrame extends JFrame {
    private JTextField txtLogin;
    private JPasswordField txtSenha;
    private JButton btnEntrar;

    public LoginFrame() {
        setTitle("Login - Locadora de Veículos");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        txtLogin = new JTextField(15);
        txtSenha = new JPasswordField(15);
        btnEntrar = new JButton("Entrar");

        btnEntrar.addActionListener(e -> autenticar());

        JPanel panel = new JPanel();
        panel.add(new JLabel("Login:"));
        panel.add(txtLogin);
        panel.add(new JLabel("Senha:"));
        panel.add(txtSenha);
        panel.add(btnEntrar);

        add(panel);
    }

    private void autenticar() {
        String login = txtLogin.getText();
        String senha = new String(txtSenha.getPassword());

        Usuario usuario = new UsuarioDAO().autenticar(login, senha);
        if (usuario != null) {
            JOptionPane.showMessageDialog(this, "Bem-vindo, " + usuario.getNome() + "!");
            dispose();
            new MainFrame(usuario).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Login ou senha inválidos.");
        }
    }
}