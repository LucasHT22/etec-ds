/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import dao.ClienteDAO;
import model.Cliente;
import util.EntradaSaidaDados;

import javax.swing.*;
import java.awt.*;

/**
 *
 * @author lucas
 */

public class CadastrarClienteFrame extends JFrame {
    private JTextField campoNome;
    private JTextField campoCpf;
    private JTextField campoTelefone;
    private JButton botaoCadastrar;
    private final EntradaSaidaDados io = new EntradaSaidaDados();

    public CadastrarClienteFrame() {
        setTitle("Cadastrar Cliente");
        setSize(350, 220);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        JPanel painel = new JPanel(new GridLayout(4, 2, 10, 10));
        campoNome = new JTextField();
        campoCpf = new JTextField();
        campoTelefone = new JTextField();
        botaoCadastrar = new JButton("Cadastrar");

        botaoCadastrar.addActionListener(e -> {
            String nome = campoNome.getText();
            String cpf = campoCpf.getText();
            String telefone = campoTelefone.getText();

            Cliente c = new Cliente(nome, cpf, telefone);
            new ClienteDAO().inserir(c);
            io.saidaDados("Cliente cadastrado com sucesso!");
        });

        painel.add(new JLabel("Nome:")); painel.add(campoNome);
        painel.add(new JLabel("CPF:")); painel.add(campoCpf);
        painel.add(new JLabel("Telefone:")); painel.add(campoTelefone);
        painel.add(botaoCadastrar);

        getContentPane().add(painel, BorderLayout.CENTER);
    }
}
