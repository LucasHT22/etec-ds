/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.time.LocalDate;

/**
 *
 * @author lucas
 */
public class Locacao {
    private int id;
    private int clienteId;
    private int veiculoId;
    private LocalDate dataInicio;
    private LocalDate dataFim;
    private double valorDiaria;
    private int numeroDias;
    private double kmRodados;
    private double valorPorKm;

    public Locacao(double valorDiaria, int numeroDias, double kmRodados, double valorPorKm) {
        this.valorDiaria = valorDiaria;
        this.numeroDias = numeroDias;
        this.kmRodados = kmRodados;
        this.valorPorKm = valorPorKm;
        this.dataInicio = LocalDate.now();
        this.dataFim = dataInicio.plusDays(numeroDias);
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getClienteId() { return clienteId; }
    public void setClienteId(int clienteId) { this.clienteId = clienteId; }

    public int getVeiculoId() { return veiculoId; }
    public void setVeiculoId(int veiculoId) { this.veiculoId = veiculoId; }

    public LocalDate getDataInicio() { return dataInicio; }
    public void setDataInicio(LocalDate dataInicio) { this.dataInicio = dataInicio; }

    public LocalDate getDataFim() { return dataFim; }
    public void setDataFim(LocalDate dataFim) { this.dataFim = dataFim; }

    public double getValorDiaria() { return valorDiaria; }
    public int getNumeroDias() { return numeroDias; }
    public double getKmRodados() { return kmRodados; }
    public double getValorPorKm() { return valorPorKm; }
}