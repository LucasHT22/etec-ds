package util;

import javax.swing.*;
import java.awt.*;

public class EntradaSaidaDados {

    public String entradaDados(String mensagemEntrada) {
        final JDialog dialog = new JDialog((Frame) null, "Entrada de Dados", true);
        dialog.setSize(400, 150);
        dialog.setLocationRelativeTo(null);

        JPanel painel = new JPanel(new GridLayout(3, 1, 5, 5));
        JLabel label = new JLabel(mensagemEntrada);
        JTextField campoEntrada = new JTextField();
        JButton botaoConfirmar = new JButton("Confirmar");

        final String[] resultado = new String[1];

        botaoConfirmar.addActionListener(e -> {
            resultado[0] = campoEntrada.getText();
            dialog.dispose();
        });

        painel.add(label);
        painel.add(campoEntrada);
        painel.add(botaoConfirmar);
        dialog.add(painel);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setVisible(true);

        return resultado[0];
    }

    public void saidaDados(String mensagemSaida) {
        JOptionPane.showMessageDialog(null, mensagemSaida);
    }
}