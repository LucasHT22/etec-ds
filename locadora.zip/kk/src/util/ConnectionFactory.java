/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author lucas
 */

public class ConnectionFactory {
    private static final String URL = "jdbc:postgresql://dpg-d0qb2nodl3ps73eq7b8g-a.oregon-postgres.render.com/locadora_ds";
    private static final String USER = "lucas";
    private static final String PASSWORD = "vOeg7Vr14dE2ZXJjAABQPaQrA845E7rj";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}