/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Veiculo;
import util.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * DATA ACCESS OBJECT
 * @author lucas
 */

public class VeiculoDAO {
    public void inserir(Veiculo v) {
        String sql = "INSERT INTO veiculos (modelo, placa, status) VALUES (?, ?, 'disponivel')";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, v.getModelo());
            stmt.setString(2, gerarPlacaAleatoria());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private String gerarPlacaAleatoria() {
        return "XYZ-" + (int)(Math.random() * 9000 + 1000);
    }
}