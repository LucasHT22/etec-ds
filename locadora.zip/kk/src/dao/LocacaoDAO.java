/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Locacao;
import util.ConnectionFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DATA ACCESS OBJECT
 * @author lucas
 */

public class LocacaoDAO {
    public void inserir(Locacao loc) {
        String sql = "INSERT INTO locacoes (cliente_id, veiculo_id, data_inicio, data_fim) VALUES (?, ?, ?, ?)";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, loc.getClienteId());
            stmt.setInt(2, loc.getVeiculoId());
            stmt.setDate(3, Date.valueOf(loc.getDataInicio()));
            stmt.setDate(4, Date.valueOf(loc.getDataFim()));

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Locacao> listarTodas() {
        List<Locacao> lista = new ArrayList<>();
        String sql = "SELECT id, cliente_id, veiculo_id, data_inicio, data_fim FROM locacoes";

        try (Connection conn = ConnectionFactory.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Locacao loc = new Locacao(0, 0, 0, 0);
                loc.setId(rs.getInt("id"));
                loc.setClienteId(rs.getInt("cliente_id"));
                loc.setVeiculoId(rs.getInt("veiculo_id"));
                loc.setDataInicio(rs.getDate("data_inicio").toLocalDate());
                loc.setDataFim(rs.getDate("data_fim").toLocalDate());
                lista.add(loc);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
